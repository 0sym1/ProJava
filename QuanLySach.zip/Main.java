import java.util.Scanner;

public class Main {
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        while (true){
            System.out.println("Dang nhap:");
            System.out.println("Nhap tai khoan, mat khau: ");

            String dangnhap = sc.nextLine();

            if(dangnhap.equals("khach")){
                QuanLySach a = new QuanLySach();
                a.khach(sc);
            }
            else{
                String mk;
                while (true){
                    mk = sc.nextLine();
                    if(mk.equals("admin")) break;
                    else System.out.println("sai mk");
                }
                QuanLySach a = new QuanLySach();
                a.admin(sc);
            }
        }
    }
}
//int n = sc.nextInt();
//sc.nextLine();
//String s = sc.nextLine();
//while (sc.hasNext()); // nhap ko gioi han
//double z = (double) 1/2;
//String s = String.format("%.5f",z); // in 5 so sau thap phan

//String.fomat("%03d",cnt);

//import java.io.*;
//import java.math.*;
//import java.security.*;
//import java.text.*;
//import java.util.*;
//import java.util.concurrent.*;
//import java.util.function.*;
//import java.util.regex.*;
//import java.util.stream.*;
//import static java.util.stream.Collectors.joining;
//import static java.util.stream.Collectors.toList;

//Integer b = Integer.parseInt(sc.nextLine());