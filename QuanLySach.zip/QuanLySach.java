import java.util.ArrayList;
import java.util.Scanner;

public class QuanLySach {
    ArrayList<Sach> book;
    public QuanLySach(){
        book = new ArrayList<Sach>();
    }
    void khach(Scanner sc){

        while (true) {
            System.out.println("1: tra cuu");
            System.out.println("2: xem danh sach");
            System.out.println("3: thoat");
            int choose = sc.nextInt();

            int ok = 0;

            switch (choose){
                case 1:
                    sc.nextLine();
                    String tmp = sc.nextLine();
                    ok = 0;
                    for(int i=0 ; i<book.size() ; i++){
                        if(book.get(i).getTieuDe().equals(tmp) || book.get(i).getTacGia().equals(tmp) || book.get(i).getTheLoai().equals(tmp) || book.get(i).getDay().equals(tmp)){
                            ok = 1;
                            book.get(i).hienThiThongTin();
                        }
                    }
                    if(ok == 0) System.out.println("404 NOT FOUND");
                    break;

                case 2:
                    for(int i = 0 ; i<book.size() ; i++){
                        System.out.println(i);
                        book.get(i).hienThiThongTin();
                    }
                    break;

                case 3:
                    ok = 2;
                    break;
            }
            if(ok == 2) break;
        }
    }

    void admin(Scanner sc) {
        while (true) {
            System.out.println("1: them sach");
            System.out.println("2: xoa sach");
            System.out.println("3: sua sach");
            System.out.println("4: cac chuc nang cua khach");
            System.out.println("5: thoat");

            int choose = sc.nextInt();
            int ok = 0;

            switch (choose){
                case 1:
                    System.out.print("Nhap so luong sach can them: ");
                    int sl = sc.nextInt();
                    sc.nextLine();
                    for (int i=1 ; i<=sl ; i++){
                        System.out.println("Them lan " + i);
                        Sach tmp = new Sach();
                        tmp.nhapThongTin(sc);
                        book.add(tmp);
                    }
                    break;

                case 2:
                    System.out.print("Nhap so luong sach muon xoa: ");
                    int sl2 ;
                    while (true){
                        sl2 = sc.nextInt();
                        if(sl2 > book.size()){
                            System.out.println("So luong sach muon xoa lon hon so sach trong thu vien, vl nhap lai: ");
                        }
                        else break;
                    }
                    for(int i=1 ; i<=sl2 ; i++){
                        System.out.println("Nhap so thu tu sach muon xoa: ");
                        int index = sc.nextInt();
                        index--;
                        book.remove(index);
                    }
                    break;

                case 3:
                    System.out.println("Nhap so sach can sua: ");
                    int sl3 ;
                    while (true){
                        sl3 = sc.nextInt();
                        if(sl3 > book.size()){
                            System.out.println("So luong sach can sua lon hon so sach trong thu vien, vl nhap lai: ");
                        }
                        else break;
                    }
                    sc.nextLine();
                    for(int i=1 ; i<=sl3 ; i++){
                        System.out.println("Nhap vi tri sach can sua: ");
                        int index = sc.nextInt();
                        index--;
                        Sach tmp2 = new Sach();

                        tmp2.nhapThongTin(sc);
                        book.set(index, tmp2);
                    }
                    break;

                case 4:
                    khach(sc);
                    break;

                case 5:
                    ok = 1;
                    break;
            }
            if(ok == 1) break;
        }
    }
}
