import java.util.Scanner;

public class Sach {
    private String tieuDe;
    private String tacGia;
    private String theLoai;
    private  String day;

    public void hienThiThongTin(){
        System.out.println("Tieu De: " + tieuDe);
        System.out.println("Tac Gia: " + tacGia);
        System.out.println("The Loai: " + theLoai);
        System.out.println("NXS: " + day);
    }

    public void nhapThongTin(Scanner sc){

        System.out.print("Tieu De: ");
        tieuDe = sc.nextLine();
        System.out.print("Tac Gia: ");
        tacGia = sc.nextLine();
        System.out.print("The Loai: ");
        theLoai = sc.nextLine();
        System.out.print("NXS: ");
        day = sc.nextLine();
    }

    public String getTieuDe() {
        return tieuDe;
    }

    public void setTieuDe(String tieuDe) {
        this.tieuDe = tieuDe;
    }

    public String getTacGia() {
        return tacGia;
    }

    public void setTacGia(String tacGia) {
        this.tacGia = tacGia;
    }

    public String getTheLoai() {
        return theLoai;
    }

    public void setTheLoai(String theLoai) {
        this.theLoai = theLoai;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }
}
